package localbrowsers;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * Created by andrew on 12/3/16.
 */
public class Edge {
    private WebDriver driver;

    @BeforeClass
    public void edgeSetup(){
        DesiredCapabilities capabilities = DesiredCapabilities.edge();
        EdgeOptions options = new EdgeOptions();
        capabilities.setCapability(ChromeOptions.CAPABILITY, options);
        driver = new EdgeDriver(capabilities);

        //System.out.println(e.findElements(By.name("a")));
        // System.out.println(e.getAttribute("innerHTML"));

        //detail-page-menu
        // driver.findElement(By.name("ytmusic-two-row-item-renderer")).click();

        //  driver.findElement(By.xpath("//button[contains(text(), 'Inloggen')]")).click();

//        WebElement cookie = driver.findElement(By.id("onetrust-accept-btn-handler"));
//        cookie.click();
//         driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
//        List<WebElement> elements = driver.findElements(By.className("search-result"));
//        System.out.println("Number of elements:" +elements.size());
//        Thread.sleep(10000);


        //https://www.funda.nl/en/koop/maarssen/beschikbaar/300000+/100+woonopp/woonhuis/1-dag/


        //onetrust-pc-btn-handler
//        List<String> newHomes=new ArrayList<>();
//        for (WebElement webElement:
//        elements ) {
//            System.out.println(webElement);
//
//
//            System.out.println( webElement.findElement(By.tagName("a")).getAttribute("href"));
//            newHomes.add(webElement.findElement(By.tagName("a")).getAttribute("href"));
//// And execute it:
//            driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS) ;
//            //webElement.findElement(By.tagName("a")).click();
//            driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS) ;
//          //  selectMultiple.perform();
//
//      //     ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
//           // driver.switchTo().window(tabs.get(1)); //switches to new tab
//            //driver.get("https://www.facebook.com");
//        }
        // driver.quit();
//        for (String url:
//        newHomes) {
//            System.out.println(url);
//           DesiredCapabilities capabilities = getDesiredCapabilities();
//            driver = new ChromeDriver(capabilities);
//            driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
//            String urls=url.split("\\?")[0];
//            driver.get(urls+"reageer");//reageer //bezichtiging
//            driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
//            cookie = driver.findElement(By.id("onetrust-accept-btn-handler"));
//            cookie.click();
//
//        }
        // Assert.assertEquals(driver.getTitle(), "Lazy Coder Origins");
    }
    @Test(groups = {"windows"})
    public void test(){
        driver.get("http://lazycoder.io/about.html");
        Assert.assertEquals(driver.getTitle(), "Lazy Coder Origins");
    }

    @AfterTest
    public void testTeardown(){
        driver.quit();
    }
}
