package localbrowsers;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.io.File;

/**
 * Created by andrew on 12/3/16.
 */
@Test(groups = {"mac", "windows"})
public class Firefox {
    private WebDriver driver;

    @BeforeTest
    public void firefoxSetup() {
        DesiredCapabilities capabilities = DesiredCapabilities.firefox();
        capabilities.setCapability("marionette", true);
        // mac requires the binary location to be set for firefox, not sure why at time of update
        FirefoxBinary ff = new FirefoxBinary(new File("/Applications/Firefox.app/Contents/MacOS/firefox-bin"));
        FirefoxProfile ffp = new FirefoxProfile();
        driver = new FirefoxDriver(ff, ffp, capabilities);
    }

    @Test
    public void test() throws InterruptedException {
        //driver.get("https://login.funda.nl/account/login?ReturnUrl=%2Fconnect%2Fauthorize%2Fcallback%3Fclient_id%3Dfunda.website%26redirect_uri%3Dhttps%253A%252F%252Fwww.funda.nl%252Fauth%252Fsignin-oidc%252F%26response_type%3Dcode%2520id_token%26scope%3Dopenid%2520profile%2520funda_basic%2520funda_login_metadata%26state%3DOpenIdConnect.AuthenticationProperties%253DtuBR9uc2LwDBbaTI1e23HFV_08EbwYO8MY5_OtrzSdWhdgzuygqqSUzeZC6F0J2WAASnBrr--gFFy_2GMxb-ElM2mw1biCRUJjJSR3Jds0B2mDZ5POrUfAX8x8bJ828LU3NS-NubBwalbt-q6nsibINutGJC1_ikGYhFRjlplX5Sd53Llq-8rCRGaCJDSmPe7bcBU76S10ggOYd2aU4nqEfqyrnWgVZWEcnYYNSu3PxaNNFG%26response_mode%3Dform_post%26nonce%3D637455562046099116.ODI3YTY1OWUtYzhmMC00MTVmLTkyMDctMTNhOTRhNzc2Y2Y5OGZhMWU1MjktNTcyMS00MGVmLWExMGQtNTRlNzA5M2ZjNDM1%26x-client-SKU%3DID_NET461%26x-client-ver%3D6.7.1.0");
       // driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
        //UserName
        //driver.findElement(By.id("UserName")).sendKeys("mmallick1990@gmail.com");
      //  driver.findElement(By.id("Password")).sendKeys("manoj028");
      //  driver.findElement(By.xpath("//button[contains(text(), 'Inloggen')]")).click();
        //Password
        //driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.get("https://www.funda.nl/en/koop/maarssen/beschikbaar/300000+/100+woonopp/woonhuis/");// 1-dag/
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
        Thread.sleep(10000);

       // WebElement cookie = driver.findElement(By.id("onetrust-accept-btn-handler"));
       // cookie.click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        Thread.sleep(10000);
        List<WebElement> elements = driver.findElements(By.className("search-result"));
        System.out.println("Number of elements:" +elements.size());


        //https://www.funda.nl/en/koop/maarssen/beschikbaar/300000+/100+woonopp/woonhuis/1-dag/


        //onetrust-pc-btn-handler
        List<String> newHomes=new ArrayList<>();
        for (WebElement webElement:
            elements ) {
            System.out.println(webElement);

            // webElement.findElement(By.tagName("a")).sendKeys(Keys.COMMAND +Keys.LEFT);

            //   Actions actions = new Actions(driver);
//            actions.keyDown(Keys.COMMAND)
//                .click(webElement.findElement(By.tagName("a"))).keyUp(Keys.COMMAND);

            //      Action selectMultiple = actions.build();

// And execute it:
            //driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
            System.out.println( webElement.findElement(By.tagName("a")).getAttribute("href"));
            newHomes.add(webElement.findElement(By.tagName("a")).getAttribute("href"));


                WebDriverWait wait = new WebDriverWait(driver,5);
                wait.until(ExpectedConditions.visibilityOf(webElement.findElement(By.tagName("a"))));
               // webElement.findElement(By.tagName("a")).sendKeys(Keys.ENTER);

                // driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS) ;
            //  selectMultiple.perform();

            //     ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
            // driver.switchTo().window(tabs.get(1)); //switches to new tab
            //driver.get("https://www.facebook.com");
        }

       // driver.quit();
        for (String url:
            newHomes) {
            System.out.println(url);
            DesiredCapabilities capabilities = DesiredCapabilities.firefox();
            capabilities.setCapability("marionette", true);
            // mac requires the binary location to be set for firefox, not sure why at time of update
            FirefoxBinary ff = new FirefoxBinary(new File("/Applications/Firefox.app/Contents/MacOS/firefox-bin"));
            FirefoxProfile ffp = new FirefoxProfile();
          //  driver = new FirefoxDriver(ff, ffp, capabilities);
            //driver = new ChromeDriver(capabilities);
            String urls=url.split("\\?")[0];
            driver.get(urls+"/bezichtiging");
            Thread.sleep(10000);
           // driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
           // cookie = driver.findElement(By.id("onetrust-accept-btn-handler"));
           // cookie.click();

        }
        Assert.assertEquals(driver.getTitle(), "Lazy Coder Origins");
    }
    @AfterTest
    public void testTeardown() {
        driver.quit();
    }
}
