package localbrowsers;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

public class Job1 implements Job {

  private WebDriver driver;

  private DesiredCapabilities getDesiredCapabilities() {
    DesiredCapabilities capabilities = DesiredCapabilities.chrome();
    ChromeOptions options = new ChromeOptions();
    options.addArguments(
        "--verbose",
        "--headless",
        "--disable-web-security",
        "--ignore-certificate-errors",
        "--allow-running-insecure-content",
        "--allow-insecure-localhost",
        "--no-sandbox",
        "--disable-gpu",
        "--disable-popup-blocking",
        "user_agent = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:46.0) Gecko/20100101 Firefox/46.0'"
    );
    capabilities.setCapability(ChromeOptions.CAPABILITY, options);
    return capabilities;
  }

  public void execute(JobExecutionContext context) throws JobExecutionException {
    System.out.println("Job1 --->>> Hello geeks! Time is " + new Date());
    DesiredCapabilities capabilities = getDesiredCapabilities();
    List<String> users = readFileIntoList("users.txt");
    List<WebDriver> drivers =new ArrayList<>();
    for (int i = 0; i < users.size(); i++) {
      try {
          System.out.println("user "+users.get(i).split(":")[0] +"is getting logged in");
        driver = new ChromeDriver(capabilities);
        driver.get("https://music.youtube.com/library/playlists");

        Thread.sleep(2000);

        List<WebElement> login = driver.findElements(By.cssSelector("a[class^='sign-in-link']"));
        if (login.size() > 0) {
          login.get(0).click();
        }
        Thread.sleep(2000);
        driver.findElement(By.id("identifierId")).sendKeys(users.get(i).split(":")[0]);
        Thread.sleep(1000);
        driver.findElements(By.cssSelector("button[class^='VfPpkd-']")).get(0).click();
        Thread.sleep(1000);
        driver.findElements(By.cssSelector("input[name='password']")).get(0)
            .sendKeys(users.get(i).split(":")[1]);
        Thread.sleep(1000);
        driver.findElements(By.cssSelector("button[class^='VfPpkd-']")).get(0).click();
        Thread.sleep(2000);
        String playlist = "";
        for (WebElement x : driver.findElement(By.id("content")).findElements(By.tagName("a"))
        ) {
          if (x.getAttribute("href").contains("playlist")) {
            playlist = x.getAttribute("href");
            break;
          }
        }
        Thread.sleep(2000);
        driver.get(playlist);
        Thread.sleep(3000);
        driver.findElement(By.id("top-level-buttons")).findElements(By.tagName("a")).get(0).click();
          drivers.add(driver);


      } catch (Exception e) {
        e.printStackTrace();
      }
    }
      List<String> time = readFileIntoList("run.txt");
      int run = Integer.parseInt(time.get(0));
      System.out.println("chrome would be closed in "+run +" hours");
      try {
          Thread.sleep(run  * 1000);
          for (WebDriver webDriver:
              drivers) {
              webDriver.quit();
          }
      } catch (InterruptedException e) {
          e.printStackTrace();
      }

  }

  public List<String> readFileIntoList(String name) {
    List<String> lines = Collections.emptyList();
    try {
      String home = System.getProperty("user.home");
      System.out.println("home path :" + home);
      if (Files.exists(Paths.get(home, "files", name))) {
        lines = Files.readAllLines(Paths.get(home, "files", name),
            StandardCharsets.UTF_8);
      } else {
        throw new FileNotFoundException("please create " + name + " file in files folder");
      }
    } catch (IOException e) {
      System.err.println(e.getMessage());
    }
    return lines;

  }
}