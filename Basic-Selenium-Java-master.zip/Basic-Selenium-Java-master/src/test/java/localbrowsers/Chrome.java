package localbrowsers;

import java.util.List;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

/**
 * Created by andrew on 12/3/16.
 */
@Test(groups = {"mac", "windows"})
public class Chrome {
    private WebDriver driver;

    @BeforeTest
    public void chromeSetup(){
        //DesiredCapabilities capabilities = getDesiredCapabilities();
       // ChromeOptions options = new ChromeOptions();
        //options.addArguments(--user-agent='Mozilla/5.0 (Macintosh; Intel Mac OS X 11_1_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36'");
        // options.addArguments("incognito");
        // options.addArguments("start-maximized");
        // options.addArguments("disable-infobars");

//        options.addArguments("--disable-web-security");
//        options.addArguments("--start-maximized");
//        options.addArguments("disable-infobars");
//        options.addArguments("--disable-notifications");
//        options.addArguments("--auto-open-devtools-for-tabs");
       // driver = new ChromeDriver(capabilities);
    }


    private DesiredCapabilities getDesiredCapabilities() {
        DesiredCapabilities capabilities = DesiredCapabilities.chrome();
        ChromeOptions options = new ChromeOptions();
        options.addArguments(
            "--verbose",
            "--headless",
            "--disable-web-security",
            "--ignore-certificate-errors",
            "--allow-running-insecure-content",
            "--allow-insecure-localhost",
            "--no-sandbox",
            "--disable-gpu",
            "--disable-popup-blocking",
            "user_agent = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:46.0) Gecko/20100101 Firefox/46.0'"
        );
        capabilities.setCapability(ChromeOptions.CAPABILITY, options);
        return capabilities;
    }

    @Test
    public void test() throws InterruptedException {
        DesiredCapabilities capabilities = getDesiredCapabilities();
        for (int i = 1; i <= 6; i++) {
            driver = new ChromeDriver(capabilities);
            driver.get("https://music.youtube.com/library/playlists");
            Thread.sleep(2000);
            List<WebElement> login =  driver.findElements(By.cssSelector("a[class^='sign-in-link']"));
            if(login.size()>0) {
                login.get(0).click();
            }
            Thread.sleep(2000);
            driver.findElement(By.id("identifierId")).sendKeys("testyoumusic"+i+"@gmail.com");
            Thread.sleep(1000);
            driver.findElements(By.cssSelector("button[class^='VfPpkd-']")).get(0).click();
            Thread.sleep(1000);
            driver.findElements(By.cssSelector("input[name='password']")).get(0).sendKeys("Manoj123");
            Thread.sleep(1000);
            driver.findElements(By.cssSelector("button[class^='VfPpkd-']")).get(0).click();
            Thread.sleep(2000);
            String playlist="";
            for ( WebElement x:driver.findElement(By.id("content")).findElements(By.tagName("a"))
            ) {
                if(x.getAttribute("href").contains("playlist")) {
                    playlist=x.getAttribute("href");
                    break;
                }
            }
            Thread.sleep(2000);
            driver.get(playlist);
            Thread.sleep(3000);
            driver.findElement(By.id("top-level-buttons")).findElements(By.tagName("a")).get(0).click();

        }


    }

    @AfterTest
    public void testTeardown(){
     //   driver.quit();

    }
}
