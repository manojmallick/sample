package localbrowsers;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.List;

public class Test {


  public static void main(String[] args) {
    List<String> lines = readFileIntoList("users.txt");
    for (String line :
        lines) {
      System.out.println(line);
    }
    List<String> runs = readFileIntoList("run.txt");
    for (String line :
        runs) {
      System.out.println(line);
    }
  }

  public static List<String> readFileIntoList(String name) {
    List<String> lines = Collections.emptyList();
    try {
      String home = System.getProperty("user.home");
      System.out.println("home path :" + home);
      if (Files.exists(Paths.get(home, "files", name))) {
        lines = Files.readAllLines(Paths.get(home, "files", name),
            StandardCharsets.UTF_8);
      } else {
        throw new FileNotFoundException("please create " + name + " file in files folder");
      }
    } catch (IOException e) {
      System.err.println(e.getMessage());
    }
    return lines;

  }



}
