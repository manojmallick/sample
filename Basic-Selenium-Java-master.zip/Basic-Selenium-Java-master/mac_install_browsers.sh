#!/usr/bin/env bash
set -ev
brew install geckodriver
brew install firefox
brew install chromedriver
#brew install google-chrome
brew install phantomjs

